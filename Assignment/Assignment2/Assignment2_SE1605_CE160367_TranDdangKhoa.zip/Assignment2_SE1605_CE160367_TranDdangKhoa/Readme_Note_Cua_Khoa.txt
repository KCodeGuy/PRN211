Dạ chào thầy. Đây là một số note của em ạ:

1. Trước khi chạy bài của em thầy chạy database tên "MyFStroreSql"
2. Đổi các thông tin trong connectionString trong file "BaseDAL" 
"Data Source=LAPTOP-F7OGOM4I\\SQLEXPRESS01;Initial Catalog=MyFStore;Integrated Security=True";  
	+ Em không sử dụng file json để connect.
	+ Đổi Data Source
      + Catalog: database name
3. Login:
	+ email: admin@fstore.com
	+ pass: admin@@
4. Assignment của em chỉ chạy được các tính năng load và update, các modul khác em đã code nhưng vẫn còn lỗi.

Cảm ơn thầy đã đọc file ạ!